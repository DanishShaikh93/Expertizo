import Router from './config/router';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
<div><h2>Header</h2></div>

       <Router/>

       <div><h2>Footer</h2></div>
      </header>
    </div>
  );
}

export default App;
