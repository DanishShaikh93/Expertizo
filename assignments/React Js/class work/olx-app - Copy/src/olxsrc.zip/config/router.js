import {
    createBrowserRouter,
    RouterProvider,
  } from "react-router-dom";

  import Homepage from "../Homepage";
  import Detail from "../Detail";

  const router = createBrowserRouter([
    {
      path: "/",
      element: <Homepage/>,
    },
    {
        path: "/ad-detail/:adId",
        element: <Detail/>,
      },
    
    
  ]);


  function Router() {
    return <RouterProvider router={router} />
  }
 
  export default Router;