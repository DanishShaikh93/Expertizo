import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function Detail() {
    const {adId}= useParams()
    const [curAd, setCurAd]=useState([]);

    useEffect(()=>{
        getCurAdd()
    }, [])

const getCurAdd= ()=>{

    fetch(`https://dummyjson.com/products/${adId}`)
    .then(res => res.json())
    .then(res => setCurAd(res));

}    
const {title, thumbnail, price, description}= curAd

    return (
        <div>
        { curAd ==[]
       ? <h2>Loading...</h2> 
       
       :<div className="adDetailBox">
        <h2>{title}</h2>
        <img src={thumbnail}/>
        <h3>{price}</h3>
        <p>{description}</p>
        </div>

        }
        </div>
    )
}

export default Detail;