import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Homepage() {
    const navigate= useNavigate()

    const [allAds, setAllAds]=useState([]);

    useEffect(()=>{
        getApiDat();
    }, [])

    const getApiDat= ()=>{
        fetch('https://dummyjson.com/products')
        .then(res => res.json())
        .then(res => setAllAds(res.products));
    }
    
   

    return (
        <div className="adSec">
{
allAds.map(item => {
    const {id, title,thumbnail,price} = item;
return <div className="adBox"> 
<h2>{title}</h2>
<img src={thumbnail}/> 
<p>${price}</p>
<button onClick={()=> navigate(`/ad-detail/${id}`)}>View Details</button>
</div>
})
}

        </div>
    )
}

export default Homepage;