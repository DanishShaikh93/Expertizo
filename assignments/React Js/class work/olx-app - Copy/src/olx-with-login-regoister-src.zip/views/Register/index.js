import { useState } from "react";
import { useNavigate } from "react-router-dom"
import { register } from "../../config/firebase";



function Register() {
    const navigate = useNavigate();
    const [name, setName]= useState();
    const [age, setAge]= useState();
    const [email, setEmail]= useState();
    const [password, setPassword]= useState();
    

const signUp = async ()=>{
  try{  
await register({name, age, email, password})
navigate("/login")
} catch (error){
 console.log(error)
}


}

    return (
        <div className="container">
        <div className="formBox">
        <h2>Enter Your Details For Registration</h2>
        <input onChange={(e) => setName(e.target.value)} type="text" placeholder="Full Name"/>
        <input onChange={(e) => setAge(e.target.value)}  type="text" placeholder="Age"/>
        <input onChange={(e) => setEmail(e.target.value)}  type="email" placeholder="Email"/>
        <input onChange={(e) => setPassword(e.target.value)}  type="password" placeholder="Password" />
        <button onClick={signUp}>Register</button>
        <p>Already have a account login your account <span onClick={()=> navigate('/Login')}>Here</span></p>
        </div>
    </div>
    )
}

export default Register