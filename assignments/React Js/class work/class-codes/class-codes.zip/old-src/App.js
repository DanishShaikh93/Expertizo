import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {
  // const txtName= "Welcom to expertizo"
  // const num= 10;
  // const isExist= true; // bolean render nhi hota
  // const someObj={
  //   ac: 2,
  //   fans:5,
  // } //object direct render nahi ho sakta but iski key value ho sakti hen

  // const someArr=["mango", "apple" , "banana"];

  // const [text, setText]= useState('Moye Moye')
  // function changeME() {
  //   setText('oye oye')
  // }

  // function reverseText() {
  //   const reverse= text.split("").reverse().join("");
  //   setText(reverse)
  // }

  // function blankText() {
  //   setText("")
  // }


  // const [imageDikhao , setImageDikhao] = useState(true);

  // function hideImage() {
  //   setImageDikhao(false)
  // }

  
  // function showImage() {
  //   setImageDikhao(true)
  // }
  
  // function toggleImage() {
  //   setImageDikhao(!imageDikhao)
  // }


  

  return (
    <div className='newCode'>
      <h2>Hello World</h2>
    </div>
    // <div className="App">
    //   <header className="App-header">
    //     { imageDikhao && <img src={logo} className="App-logo" alt="logo" />}
    //     <button onClick={hideImage}>Hide Image</button>
    //     <button onClick={showImage}>show Image</button>
    //     <button onClick={toggleImage}>toggle Image</button>
    //     <p>
    //       <h1>{text}</h1>
    //       <button onClick={changeME}>Change Me</button><br/>
    //       <button onClick={reverseText}>Reverse Text</button> <br/>
    //       <button onClick={blankText}>Blank Text</button> <br/>
    //       {txtName}
    //       {num}
    //       {isExist}
    //       {someObj.ac}
    //       <br />
    //       <ul>
    //       {someArr.map(function (item) {
    //         return <li>{item}</li>
    //       })}
    //       </ul>
    //     </p>
        
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
  );
}

export default App;
