// LocalStoragePage.js
import React, { useState, useEffect } from 'react';

function LocalStoragePage() {
    const [searchRecords, setSearchRecords] = useState([]);

    useEffect(() => {
        const records = JSON.parse(localStorage.getItem('searchRecords')) || [];
        setSearchRecords(records);
    }, []);

    return (
        <div className="local-storage-page">
            <h2>Search Records from Local Storage</h2>
            <ul>
                {searchRecords.map((record, index) => (
                    <li key={index}>
                        <strong>Query:</strong> {record.searchQuery}, <strong>Temperature:</strong> {record.weatherData.temp}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default LocalStoragePage;
