import Link from 'next/link'
export default function AboutUs() {
    return (
        <>
        <h2>About Us</h2>
        
        <Link href="dashboard">Dashboard</Link>
        <Link href="about-us">About Us</Link>
        </>
    )
}