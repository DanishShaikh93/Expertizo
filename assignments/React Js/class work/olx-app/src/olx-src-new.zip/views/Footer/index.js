function Footer() {
    
    return (
    <div className="footer-sec">

    </div>
    )
}

export default Footer;