import logo from '../../images/logo.png'
import carIco from '../../images/car.png'
import propertyIco from '../../images/property.png'
import search from '../../images/search.png'
function Header() {
    
    return (
    <div className="container-fluid headerSec">
        <div className="container">
            <div className="topBar">
                <div><img src={logo} height="20" alt="logo"/></div>
                <div className='tpIco'><span><i><img src={carIco} height="30" alt="car"/></i> Motors</span></div>
                <div className='tpIco'><span><i><img src={propertyIco} height="30" alt="property"/></i>Property</span></div>
            </div>

            <div className='headerMiddle'>
                <div className='logoMain'><img src={logo} height="30" alt="logo"/></div>

                <div className='countryDropdown'>
                    <form>
                    <select>
                        <option selected>Pakistan</option>
                        <option selected>Pakistan</option>
                        <option selected>Pakistan</option>
                    </select>
                    </form>
                </div>

                <div className='searchBox'>
                   <input type='text' placeholder='Find Cars, Mobile Phones and more...'/>
                   <button><img src={search} height="20"/></button>
                </div>

                <div className='loginSellBtns'>
                    <button className='simpleBtn'>Login</button>
                    <button className='multiBtn'>+ Sell</button>
                </div>

            </div>
        </div>

    </div>
    )
}

export default Header;