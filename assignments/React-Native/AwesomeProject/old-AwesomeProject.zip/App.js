import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native'
import {createNativeStackNavigator} from '@react-navigation/native-stack'
import Home from './screens/Home';
import UserCamera from './screens/UserCamera';


const Stack = createNativeStackNavigator();

// const Home = ()=>{
//   return <Text>Homepage</Text>
// }

// const UserCam = ()=>{
//   return <Text>User Camera asas</Text>
// }


export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name='home' component={Home} 
        options={{
          headerTitle: "Home Main",
          headerTintColor: "#fff",
          headerStyle: {
            backgroundColor: "blue",
          }
        }}
        />
      <Stack.Screen name='camera' component={UserCamera} />
       
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// });
